package com.monlanceur.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.max

/**
 * Écran d'accueil du launcher.
 *
 * - Accueil : horloge, date et applications favorites
 * - Glisser vers le haut (ou toucher le bouton du bas) : liste de toutes les applications
 * - Appui long sur une application : favoris, informations, désinstallation
 * - Appui long sur le fond de l'accueil : changer le fond d'écran
 */
class MainActivity : Activity() {

    private lateinit var home: View
    private lateinit var drawer: View
    private lateinit var drawerList: RecyclerView
    private lateinit var searchBox: EditText
    private lateinit var prefs: SharedPreferences
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var favoritesAdapter: AppAdapter
    private lateinit var swipeDetector: GestureDetector

    private var allApps: List<AppInfo> = emptyList()
    private var shownApps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        home = findViewById(R.id.home)
        drawer = findViewById(R.id.drawer)
        drawerList = findViewById(R.id.drawerList)
        searchBox = findViewById(R.id.search)

        // Laisse de la place pour la barre d'état, la barre de navigation et le clavier
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, max(bars.bottom, ime.bottom))
            insets
        }

        drawerAdapter = AppAdapter(
            onClick = { launch(it) },
            onLongClick = { view, app -> showAppMenu(view, app) }
        )
        favoritesAdapter = AppAdapter(
            onClick = { launch(it) },
            onLongClick = { view, app -> showAppMenu(view, app) }
        )
        setupList(drawerList, drawerAdapter)
        setupList(findViewById(R.id.favorites), favoritesAdapter)

        findViewById<View>(R.id.open_drawer).setOnClickListener { openDrawer() }
        home.setOnLongClickListener {
            openWallpaperPicker()
            true
        }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter(s?.toString().orEmpty())
            }
        })
        // Touche "OK" du clavier : ouvre le premier résultat
        searchBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                shownApps.firstOrNull()?.let { launch(it) }
                true
            } else {
                false
            }
        }

        // Glisser vers le haut sur l'accueil : ouvre le tiroir d'applications
        val density = resources.displayMetrics.density
        swipeDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (dy < -80 * density && abs(dy) > abs(dx) && velocityY < -800f) {
                    openDrawer()
                    return true
                }
                return false
            }
        })
        swipeDetector.setIsLongpressEnabled(false)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Appui sur le bouton Accueil : on revient à l'écran d'accueil
        closeDrawer()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (drawer.visibility != View.VISIBLE) {
            swipeDetector.onTouchEvent(ev)
        }
        return super.dispatchTouchEvent(ev)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Sur un launcher, "Retour" ferme seulement le tiroir et ne quitte jamais l'accueil
        if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    // ---------------------------------------------------------------- applications

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    activityName = it.activityInfo.name,
                    icon = it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
        refreshLists()
    }

    private fun refreshLists() {
        val favorites = favorites()
        favoritesAdapter.submit(allApps.filter { it.packageName in favorites })
        applyFilter(searchBox.text.toString())
    }

    private fun applyFilter(text: String) {
        val query = text.trim().lowercase()
        shownApps = if (query.isEmpty()) {
            allApps
        } else {
            allApps.filter { it.label.lowercase().contains(query) }
        }
        drawerAdapter.submit(shownApps)
    }

    private fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        if (safeStart(intent)) {
            closeDrawer()
        } else {
            Toast.makeText(this, R.string.launch_error, Toast.LENGTH_SHORT).show()
        }
    }

    private fun safeStart(intent: Intent): Boolean = try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    // ---------------------------------------------------------------- favoris et menu

    private fun favorites(): Set<String> =
        prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()

    private fun toggleFavorite(packageName: String) {
        val updated = favorites().toMutableSet()
        if (!updated.add(packageName)) updated.remove(packageName)
        prefs.edit().putStringSet(KEY_FAVORITES, updated).apply()
        refreshLists()
    }

    private fun showAppMenu(anchor: View, app: AppInfo) {
        val isFavorite = app.packageName in favorites()
        PopupMenu(this, anchor).apply {
            menu.add(
                0, MENU_FAVORITE, 0,
                getString(if (isFavorite) R.string.remove_favorite else R.string.add_favorite)
            )
            menu.add(0, MENU_INFO, 1, getString(R.string.app_info))
            menu.add(0, MENU_UNINSTALL, 2, getString(R.string.uninstall))
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    MENU_FAVORITE -> toggleFavorite(app.packageName)
                    MENU_INFO -> safeStart(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")
                        )
                    )
                    MENU_UNINSTALL -> safeStart(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                    )
                }
                true
            }
            show()
        }
    }

    private fun openWallpaperPicker() {
        safeStart(
            Intent.createChooser(
                Intent(Intent.ACTION_SET_WALLPAPER),
                getString(R.string.wallpaper)
            )
        )
    }

    // ---------------------------------------------------------------- tiroir

    private fun setupList(list: RecyclerView, listAdapter: AppAdapter) {
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = listAdapter
    }

    private fun openDrawer() {
        drawer.animate().cancel()
        searchBox.setText("")
        drawerList.scrollToPosition(0)
        drawer.alpha = 0f
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).setDuration(150).start()
    }

    private fun closeDrawer() {
        if (drawer.visibility != View.VISIBLE) return
        hideKeyboard()
        drawer.animate().cancel()
        drawer.animate()
            .alpha(0f)
            .setDuration(150)
            .withEndAction { drawer.visibility = View.GONE }
            .start()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
    }

    private companion object {
        const val PREFS = "launcher"
        const val KEY_FAVORITES = "favorites"
        const val MENU_FAVORITE = 1
        const val MENU_INFO = 2
        const val MENU_UNINSTALL = 3
    }
}
