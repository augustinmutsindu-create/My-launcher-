package com.monlanceur.launcher

import android.graphics.drawable.Drawable

/** Une application installée sur le téléphone. */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)
