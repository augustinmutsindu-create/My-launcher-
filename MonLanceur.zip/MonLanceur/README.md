# Mon Lanceur

Un launcher Android simple : horloge, date, applications favorites, liste de toutes les applications avec recherche. Le fond d'écran de votre téléphone reste visible.

## Installer et tester

1. Installez **Android Studio** (gratuit) sur votre ordinateur : https://developer.android.com/studio
2. Décompressez ce dossier, puis dans Android Studio : **File > Open** et choisissez le dossier `MonLanceur`.
3. Attendez la fin de la synchronisation Gradle (barre de progression en bas). Si Android Studio propose une mise à jour, acceptez.
4. Sur votre téléphone : **Paramètres > À propos du téléphone**, touchez 7 fois « Numéro de build », puis activez **Options pour les développeurs > Débogage USB**.
5. Branchez le téléphone en USB, acceptez l'autorisation, puis cliquez sur le bouton vert **Run** dans Android Studio.
6. Sur le téléphone, appuyez sur le bouton **Accueil** : Android demande quel écran d'accueil utiliser. Choisissez **Mon Lanceur**, puis **Toujours**.

## Obtenir l'APK à installer sur d'autres téléphones

**Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio indique où se trouve le fichier `app-debug.apk`.

## Obtenir l'APK sans Android Studio (compilation en ligne avec GitHub)

1. Créez un compte gratuit sur https://github.com, puis **New repository** (nom : `MonLanceur`, visibilité au choix).
2. Sur la page du dépôt, cliquez **uploading an existing file** et glissez-y **tout le contenu** du dossier `MonLanceur` (les dossiers `app` et `gradle` et tous les fichiers). Validez avec **Commit changes**.
3. Vérifiez que le fichier `.github/workflows/build-apk.yml` est bien présent dans le dépôt. S'il manque (les dossiers cachés sont parfois ignorés au glisser-déposer) : **Add file > Create new file**, tapez le nom `.github/workflows/build-apk.yml` (les `/` créent les dossiers), collez le contenu du fichier `build-apk.yml` fourni, puis **Commit changes**.
4. Ouvrez l'onglet **Actions**. La compilation démarre toute seule (sinon : **Build APK > Run workflow**). Comptez 3 à 6 minutes.
5. Quand la ligne est verte, cliquez dessus, puis en bas dans **Artifacts** sur **MonLanceur-apk**. Vous téléchargez un zip qui contient `app-debug.apk`.
6. Copiez l'APK sur le téléphone et ouvrez-le. Autorisez l'installation depuis cette source si Android le demande.

Si la ligne est rouge, ouvrez-la, copiez le message d'erreur et envoyez-le pour correction.

## Utilisation

- **Glisser vers le haut** (ou toucher « Toutes les applications ») : liste des applications
- **Taper dans la recherche**, puis touche « OK » du clavier : ouvre le premier résultat
- **Appui long sur une application** : ajouter aux favoris, informations, désinstaller
- **Appui long sur le fond de l'accueil** : changer le fond d'écran
- **Bouton Retour** : ferme la liste des applications

## Revenir à votre ancien écran d'accueil

**Paramètres > Applications > Applications par défaut > Application d'accueil**, puis choisissez l'ancien.

## Où modifier quoi

| Fichier | Contenu |
|---|---|
| `app/src/main/java/com/monlanceur/launcher/MainActivity.kt` | Comportement du launcher |
| `app/src/main/res/layout/activity_main.xml` | Disposition de l'accueil et du tiroir |
| `app/src/main/res/layout/item_app.xml` | Aspect d'une ligne d'application |
| `app/src/main/res/values/strings.xml` | Textes affichés |
| `app/src/main/res/drawable/ic_launcher.xml` | Icône de l'application |
